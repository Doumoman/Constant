# SV5_20 FIX05 — RMAP direct-regression scene isolation

The combined RMAP02–04 PlayMode gate failed because SavedScene tests left
loaded scene colliders for the following suite. Both failing tests passed in
fresh, separate Unity processes, proving cross-test contamination rather than a
Player, climb, Grab, or map defect.

FIX05 authorizes test-lifecycle changes in exactly two files:

- `RMAP02/GeneratedTilemapPlayerRunPlayModeTests.cs`
- `RMAP03/CharacterLiveGrabPlayModeTests.cs`

Saved scenes must be loaded additively, inspected through their explicit Scene,
and unloaded in `finally` while the prior active Scene is restored. Test-owned
physical roots must also be destroyed in `finally`, followed by one rendered
frame and `Physics2D.SyncTransforms()` before the next test can begin.

The four temporary `RMAP03_Focused_*Diagnostic` methods were created only to
identify the actual-capsule and fixture-leak causes. They are not part of the
accepted RMAP03 regression contract and must be removed before the final direct
gate. Shared helpers used by the ten original tests and the natural-recontact
proof remain.

FIX05 does not permit changes to product code, Player tuning, prefab/capsule,
Physics2D settings, saved Scene assets, fixture geometry, movement assertions,
or post-START position/velocity. The final combined direct regression must be
exactly 21/21: RMAP02 5, RMAP03 10, and RMAP04 6.
