from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path


BASE = "660d0c58ec0f65cbbbe200716d0e3c36b0ea4ba7"
TASK = "SV5_20_JUMP_PLAYER"
DRIVER = "Assets/_Game/Live/Runtime/Movement/CharacterLiveMovementDriver.cs"
DRIVER_SHA = "77ac90e6c65f4dc83a104deb1db6c02177b1c50c2797426c6e3b07aeedc0d8f8"
DRIVER_BYTES = 39703
STATUS = "MapDesign/MCP/06_IMPLEMENTATION_STATUS.md"
OLD_SHA = {
    "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/CONTRACT.md": "59726bd4735c32f43a56638afb2bc4b264fbb0ba8f9de55e832eab2dd49993d3",
    "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/FILES.json": "2406dddf7f9ea25381c4329a02f395c6947b8449cc0e2a84567af8851f74188d",
    "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/README.md": "492f12244c34bf4489173505136bffa9b8ab7df164144b4562085865362bf4ce",
    "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/SOURCE_LOCK.json": "3b7525e549dab886b664926cd46dc94a783553369a6482628a1dfbd2ca057616",
    "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/STAGE.py": "da5706a766a9b950c8258f3a0a36a24ae52ee962d16e03a5f9f5409eda3c045f",
    "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/SV5_20_JUMP_PLAYER.md": "a4e87175a19777f2c2879842618b70af50882c2f87122604e7e6cc388e0249d0",
    "MapDesign/MCP/TASKS/SV5_20_JUMP_PLAYER.md": "a4e87175a19777f2c2879842618b70af50882c2f87122604e7e6cc388e0249d0",
    "MapDesign/MCP_ARCHIVE/SV5_20_JUMP_PLAYER.md": "a4e87175a19777f2c2879842618b70af50882c2f87122604e7e6cc388e0249d0",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def package_entries(here: Path) -> tuple[list[dict], list[str]]:
    errors: list[str] = []
    manifest_path = here / "PACKAGE_MANIFEST.json"
    if not manifest_path.is_file():
        return [], ["PACKAGE_MANIFEST_MISSING"]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [], ["PACKAGE_MANIFEST_PARSE:" + str(exc)]
    if manifest.get("schema") != "SV5_20_FIX05_PATCH_FILES/v1":
        errors.append("PACKAGE_MANIFEST_SCHEMA")
    if manifest.get("base_commit") != BASE:
        errors.append("PACKAGE_MANIFEST_BASE")
    if manifest.get("amendment") != "SV5_20_FIX05_RMAP_SCENE_ISOLATION":
        errors.append("PACKAGE_MANIFEST_AMENDMENT")
    entries = manifest.get("payload", [])
    seen: set[str] = set()
    for entry in entries:
        rel = entry.get("path", "")
        if rel in seen:
            errors.append("PACKAGE_DUPLICATE:" + rel)
        seen.add(rel)
        path = here / "payload" / rel
        try:
            path.resolve().relative_to((here / "payload").resolve())
        except ValueError:
            errors.append("PACKAGE_UNSAFE_PATH:" + rel)
            continue
        if not path.is_file():
            errors.append("PACKAGE_FILE_MISSING:" + rel)
            continue
        raw = path.read_bytes()
        if digest(raw) != entry.get("sha256") or len(raw) != entry.get("bytes"):
            errors.append("PACKAGE_BYTES:" + rel)
    return entries, errors


def preflight(root: Path, here: Path, require_new: bool) -> tuple[list[dict], list[str]]:
    entries, errors = package_entries(here)
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    ).stdout.strip()
    if head != BASE:
        errors.append("HEAD_MISMATCH:" + head)
    status_path = root / STATUS
    if not status_path.is_file():
        errors.append("STATUS_MISSING")
    else:
        status = status_path.read_text(encoding="utf-8-sig")
        if status.count(f"| {TASK} | CURRENT |") != 1:
            errors.append("TASK_NOT_CURRENT")
        current = re.search(r"## Current Task\s*```text\s*([^\r\n]+)", status)
        if not current or current.group(1).strip() != TASK:
            errors.append("CURRENT_BLOCK_MISMATCH")
        if status.count("| SV5_21_LIBRARY | LOCKED |") != 1:
            errors.append("SV5_21_NOT_LOCKED")
    driver = root / DRIVER
    if not driver.is_file():
        errors.append("APPROVED_DRIVER_MISSING")
    else:
        raw = driver.read_bytes()
        if digest(raw) != DRIVER_SHA or len(raw) != DRIVER_BYTES:
            errors.append("APPROVED_DRIVER_BYTES")
    for entry in entries:
        rel = entry["path"]
        target = root / rel
        expected = entry["sha256"]
        if not target.exists():
            if require_new or rel in OLD_SHA:
                errors.append("TARGET_MISSING:" + rel)
            continue
        if not target.is_file():
            errors.append("TARGET_NOT_FILE:" + rel)
            continue
        actual = digest(target.read_bytes())
        if require_new:
            if actual != expected:
                errors.append("TARGET_NOT_CORRECTED:" + rel)
        elif actual != expected and actual != OLD_SHA.get(rel):
            errors.append("TARGET_UNEXPECTED_BYTES:" + rel)
    return entries, errors


def install(root: Path, here: Path, entries: list[dict]) -> None:
    before: dict[str, bytes | None] = {}
    written: list[Path] = []
    try:
        for entry in entries:
            rel = entry["path"]
            source = here / "payload" / rel
            target = root / rel
            data = source.read_bytes()
            if target.is_file() and target.read_bytes() == data:
                continue
            before[rel] = target.read_bytes() if target.is_file() else None
            target.parent.mkdir(parents=True, exist_ok=True)
            temp = target.with_name(target.name + ".SV5_20_FIX05.tmp")
            if temp.exists():
                raise RuntimeError("TEMP_COLLISION:" + rel)
            temp.write_bytes(data)
            os.replace(temp, target)
            written.append(target)
    except Exception:
        for target in reversed(written):
            rel = target.relative_to(root).as_posix()
            old = before[rel]
            if old is None:
                target.unlink(missing_ok=True)
            else:
                temp = target.with_name(target.name + ".SV5_20_FIX05.rollback")
                temp.write_bytes(old)
                os.replace(temp, target)
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--check", action="store_true")
    modes.add_argument("--apply", action="store_true")
    modes.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    here = Path(__file__).resolve().parent
    entries, errors = preflight(root, here, args.verify)
    if errors:
        print(json.dumps({"status": "BLOCKED", "errors": errors}, indent=2))
        return 1
    if args.apply:
        install(root, here, entries)
        _, errors = preflight(root, here, True)
        if errors:
            print(json.dumps({"status": "BLOCKED_AFTER_APPLY", "errors": errors}, indent=2))
            return 1
        status = "PASS_FIX05_APPLIED"
    elif args.verify:
        status = "PASS_FIX05_VERIFIED"
    else:
        status = "PASS_FIX05_PREFLIGHT"
    input_manifest = root / "MapDesign/MCP/INPUTS/SV5_20_JUMP_PLAYER/FILES.json"
    print(json.dumps({
        "status": status,
        "head": BASE,
        "task": TASK,
        "payload_files": len(entries),
        "approved_driver_sha256": DRIVER_SHA,
        "input_manifest_sha256": digest(input_manifest.read_bytes()) if input_manifest.is_file() else None,
        "status_changed_by_installer": False,
        "tests_executed_by_installer": False,
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
