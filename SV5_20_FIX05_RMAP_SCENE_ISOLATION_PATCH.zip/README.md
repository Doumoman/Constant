# SV5_20 FIX05 RMAP Scene Isolation Patch

This correction package amends the already-CURRENT `SV5_20_JUMP_PLAYER`
contract. It does not register or Apply a new Task and it does not edit product
code. It authorizes lifecycle-only cleanup in the RMAP02 and RMAP03 PlayMode
test harnesses so SavedScene and fixture colliders cannot leak into the next
suite.

Run `APPLY_FIX05.py --check`, `--apply`, and `--verify` from a temporary
extraction directory. The installer requires the accepted FIX04 bytes, the
approved Player driver bytes, the base HEAD, `SV5_20` CURRENT, and `SV5_21`
LOCKED. It is transactional and idempotent.

After installation, implement only the two approved test-harness lifecycle
changes described by `FIX05_RMAP_SCENE_ISOLATION_AMENDMENT.md`.
