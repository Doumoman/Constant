using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using StarNight.Map.WorldGeneration.SpecialRegions;
using StarNight.Map.WorldGeneration.WorldData;

namespace StarNight.Map.WorldGeneration.SectorPlanning
{
    /// <summary>The typed RMAP13 predicate owned by one physical planned boundary.</summary>
    public sealed class Sv5SpaceGatePredicate : IEquatable<Sv5SpaceGatePredicate>
    {
        public Sv5SpaceGatePredicate(ulong requiredResourceMask, bool requiresForge, bool requiresSeal,
            bool requiresBossComplete)
        {
            RequiredResourceMask = requiredResourceMask;
            RequiresForge = requiresForge;
            RequiresSeal = requiresSeal;
            RequiresBossComplete = requiresBossComplete;
        }

        public ulong RequiredResourceMask { get; }
        public bool RequiresForge { get; }
        public bool RequiresSeal { get; }
        public bool RequiresBossComplete { get; }
        public string StableToken => "mask=" + RequiredResourceMask.ToString(CultureInfo.InvariantCulture) +
            ",forge=" + (RequiresForge ? "1" : "0") + ",seal=" + (RequiresSeal ? "1" : "0") +
            ",boss=" + (RequiresBossComplete ? "1" : "0");

        public bool IsOpen(ulong resourceMask, bool forgeMade, bool sealOpen, bool bossComplete) =>
            (resourceMask & RequiredResourceMask) == RequiredResourceMask &&
            (!RequiresForge || forgeMade) && (!RequiresSeal || sealOpen) &&
            (!RequiresBossComplete || bossComplete);

        internal static Sv5SpaceGatePredicate FromEdge(RmapWorldGraphEdge edge) => edge == null ? null :
            new Sv5SpaceGatePredicate(edge.RequiredResourceMask, edge.RequiresForge, edge.RequiresSeal,
                edge.RequiresBossComplete);

        public bool Equals(Sv5SpaceGatePredicate other) => other != null &&
            RequiredResourceMask == other.RequiredResourceMask && RequiresForge == other.RequiresForge &&
            RequiresSeal == other.RequiresSeal && RequiresBossComplete == other.RequiresBossComplete;
        public override bool Equals(object obj) => Equals(obj as Sv5SpaceGatePredicate);
        public override int GetHashCode()
        {
            unchecked
            {
                int hash = RequiredResourceMask.GetHashCode();
                hash = hash * 397 ^ RequiresForge.GetHashCode();
                hash = hash * 397 ^ RequiresSeal.GetHashCode();
                return hash * 397 ^ RequiresBossComplete.GetHashCode();
            }
        }
        public override string ToString() => StableToken;
    }

    public sealed class Sv5SpaceGateStateCheck : IComparable<Sv5SpaceGateStateCheck>
    {
        internal Sv5SpaceGateStateCheck(string id, Sv5SpaceGate gate, ulong resourceMask, bool forgeMade,
            bool sealOpen, bool bossComplete, bool expectedOpen, bool actualOpen, bool sourceAnchorReachable,
            bool targetPortReachable, bool sealedCutVerified, bool openPathVerified, int checkedCells,
            int checkedFaces, string evidence)
        {
            Id = id;
            GateId = gate.Id;
            ConnectionId = gate.SourceConnectionId;
            SourcePortId = gate.SourcePortId;
            TargetPortId = gate.TargetPortId;
            ResourceMask = resourceMask;
            ForgeMade = forgeMade;
            SealOpen = sealOpen;
            BossComplete = bossComplete;
            ExpectedOpen = expectedOpen;
            ActualOpen = actualOpen;
            SourceAnchorReachable = sourceAnchorReachable;
            TargetPortReachable = targetPortReachable;
            SealedCutVerified = sealedCutVerified;
            OpenPathVerified = openPathVerified;
            CheckedCells = checkedCells;
            CheckedFaces = checkedFaces;
            Evidence = evidence ?? string.Empty;
        }

        public string Id { get; }
        public string GateId { get; }
        public string ConnectionId { get; }
        public string SourcePortId { get; }
        public string TargetPortId { get; }
        public ulong ResourceMask { get; }
        public bool ForgeMade { get; }
        public bool SealOpen { get; }
        public bool BossComplete { get; }
        public bool ExpectedOpen { get; }
        public bool ActualOpen { get; }
        public bool SourceAnchorReachable { get; }
        public bool TargetPortReachable { get; }
        public bool SealedCutVerified { get; }
        public bool OpenPathVerified { get; }
        public int CheckedCells { get; }
        public int CheckedFaces { get; }
        public string Evidence { get; }
        public bool Success => ExpectedOpen == ActualOpen && SourceAnchorReachable && SealedCutVerified &&
            OpenPathVerified && TargetPortReachable == ExpectedOpen;
        public int CompareTo(Sv5SpaceGateStateCheck other) => other == null ? 1 :
            string.Compare(Id, other.Id, StringComparison.Ordinal);
    }

    /// <summary>
    /// Builds and validates route-owned physical cuts before the projected FSM is searched.
    /// INFILL_PENDING is never added to this movement graph: only the accepted connection envelope is consumed.
    /// </summary>
    public static class Sv5SpaceGateGeometry
    {
        internal static IReadOnlyList<Sv5SpaceGate> Build(Sv5CoreReservationPlan core,
            IEnumerable<Sv5SpaceConnection> sourceConnections, IEnumerable<Sv5RouteContactPair> sourceContacts)
        {
            if (core == null) throw new ArgumentNullException(nameof(core));
            Sv5SpaceConnection[] connections = (sourceConnections ?? Array.Empty<Sv5SpaceConnection>())
                .Where(value => value != null).OrderBy(value => value).ToArray();
            Sv5RouteContactPair[] contacts = (sourceContacts ?? Array.Empty<Sv5RouteContactPair>())
                .Where(value => value != null).ToArray();
            var edges = core.RouteSource.Graph.Edges.ToDictionary(value => value.EdgeId, value => value,
                StringComparer.Ordinal);
            var globalPassage = new HashSet<RmapSpecialWorldPoint>(connections.SelectMany(value =>
                value.Centerline.Concat(value.ApertureCells)));
            Sv5SpaceConnection[] guarded = connections.Where(value => value.Kind ==
                         Sv5SpaceConnectionKind.CoreProgression && edges.TryGetValue(value.SourceGraphEdgeId,
                             out RmapWorldGraphEdge edge) && IsGuarded(edge))
                .OrderBy(value => edges[value.SourceGraphEdgeId].RequiresBossComplete ? 3 :
                    edges[value.SourceGraphEdgeId].RequiresSeal ? 2 : 1)
                .ThenBy(value => value.FromPortId, StringComparer.Ordinal).ToArray();
            var selected = new List<Sv5SpaceGate>();
            if (Select(0)) return new ReadOnlyCollection<Sv5SpaceGate>(selected.OrderBy(value => value).ToArray());
            // A layout with no legal cut is inspectable but cannot pass production acceptance.
            return new ReadOnlyCollection<Sv5SpaceGate>(guarded.Select(c => Candidate(c, false))
                .OrderBy(value => value).ToArray());

            bool Select(int index)
            {
                if (index == guarded.Length) return true;
                foreach (bool atSource in new[] { true, false })
                {
                    Sv5SpaceGate candidate = Candidate(guarded[index], atSource);
                    if (selected.Any(g => g.BlockingFaces.Any(f =>
                        candidate.BlockingFaces.Any(c => c.StableToken == f.StableToken)))) continue;
                    Sv5SpaceGate[] trial = selected.Concat(new[] { candidate }).ToArray();
                    if (!Sv5SpacePhysicalProduct.PreservesExpectedOpen(core, connections, trial)) continue;
                    selected.Add(candidate);
                    if (Select(index + 1)) return true;
                    selected.RemoveAt(selected.Count - 1);
                }
                return false;
            }

            Sv5SpaceGate Candidate(Sv5SpaceConnection connection, bool atSource)
            {
                RmapWorldGraphEdge edge = edges[connection.SourceGraphEdgeId];
                string portId = atSource ? connection.FromPortId : connection.ToPortId;
                var region = new HashSet<RmapSpecialWorldPoint>(core.Source.Accesses.Single(a => a.Id == portId).OpenCells);
                var localFaces = new List<Sv5SpaceBoundaryFace>();
                var localCells = new List<RmapSpecialWorldPoint>();
                var foreignPassage = new HashSet<RmapSpecialWorldPoint>(connections.Where(value => value.Id != connection.Id)
                    .SelectMany(value => value.Centerline.Concat(value.ApertureCells)));
                var foreignFaces = new HashSet<string>(connections.Where(value => value.Id != connection.Id)
                    .SelectMany(value => value.Centerline.Zip(value.Centerline.Skip(1),
                        (a, b) => new Sv5SpaceBoundaryFace(a, b).StableToken)), StringComparer.Ordinal);
                var foreignPortCells = new HashSet<RmapSpecialWorldPoint>(core.Source.Accesses
                    .Where(a => a.Id != connection.FromPortId && a.Id != connection.ToPortId)
                    .SelectMany(a => a.OpenCells));
                string routeKeyForContact = Sv5SpaceGraphPlanner.RouteKey(connection);
                var protectedAir = new HashSet<RmapSpecialWorldPoint>(core.CoreCells.Where(c =>
                    c.Protection == RmapSpecialProtectionKind.ProtectedAir).Select(c => c.World));
                var portCells = new HashSet<RmapSpecialWorldPoint>(core.Source.Accesses.SelectMany(a => a.OpenCells));
                foreach (Sv5RouteContactPair contact in contacts.Where(value =>
                    value.RouteA == routeKeyForContact || value.RouteB == routeKeyForContact))
                {
                    if (contact.Kind == "SHARED" && !protectedAir.Contains(contact.FirstWorld) &&
                        !portCells.Contains(contact.FirstWorld) && !foreignPassage.Contains(contact.FirstWorld) &&
                        !foreignPortCells.Contains(contact.FirstWorld)) localCells.Add(contact.FirstWorld);
                    else if (contact.Kind == "FACE" && globalPassage.Contains(contact.FirstWorld) &&
                        globalPassage.Contains(contact.SecondWorld) && !protectedAir.Contains(contact.FirstWorld) &&
                        !protectedAir.Contains(contact.SecondWorld) && !portCells.Contains(contact.FirstWorld) &&
                        !portCells.Contains(contact.SecondWorld) && !foreignFaces.Contains(new Sv5SpaceBoundaryFace(contact.FirstWorld, contact.SecondWorld).StableToken) &&
                        !foreignPassage.Contains(contact.FirstWorld) && !foreignPassage.Contains(contact.SecondWorld) &&
                        !foreignPortCells.Contains(contact.FirstWorld) && !foreignPortCells.Contains(contact.SecondWorld))
                        localFaces.Add(new Sv5SpaceBoundaryFace(contact.FirstWorld, contact.SecondWorld));
                }
                foreach (RmapSpecialWorldPoint first in region)
                foreach (RmapSpecialWorldPoint second in Neighbors(first).Where(n => globalPassage.Contains(n) &&
                    !region.Contains(n) && !protectedAir.Contains(first) && !protectedAir.Contains(n) &&
                    !portCells.Contains(first) && !portCells.Contains(n)))
                    if (!foreignFaces.Contains(new Sv5SpaceBoundaryFace(first, second).StableToken) &&
                        !foreignPassage.Contains(first) && !foreignPassage.Contains(second) &&
                        !foreignPortCells.Contains(first) && !foreignPortCells.Contains(second))
                        localFaces.Add(new Sv5SpaceBoundaryFace(first, second));
                if (edge.RequiresSeal || edge.RequiresBossComplete)
                {
                    GateCut full = FullWidthCut(core, connection);
                    foreach (Sv5SpaceBoundaryFace face in full.Faces.Where(f =>
                        globalPassage.Contains(f.First) && globalPassage.Contains(f.Second) &&
                        true))
                        if (!foreignFaces.Contains(face.StableToken) &&
                            !foreignPassage.Contains(face.First) && !foreignPassage.Contains(face.Second) &&
                            !foreignPortCells.Contains(face.First) && !foreignPortCells.Contains(face.Second)) localFaces.Add(face);
                    var targetRegion = new HashSet<RmapSpecialWorldPoint>(core.Source.Accesses
                        .Single(a => a.Id == connection.ToPortId).OpenCells);
                    foreach (RmapSpecialWorldPoint target in targetRegion)
                    foreach (RmapSpecialWorldPoint next in Neighbors(target).Where(globalPassage.Contains)
                        .Where(next => !targetRegion.Contains(next)))
                        if (!foreignPassage.Contains(target) && !foreignPassage.Contains(next) &&
                            !foreignPortCells.Contains(target) && !foreignPortCells.Contains(next))
                            localFaces.Add(new Sv5SpaceBoundaryFace(target, next));
                }
                Sv5SpaceBoundaryFace[] faces = localFaces.Distinct().OrderBy(value => value).ToArray();
                if (faces.Length == 0 && localCells.Count == 0)
                    throw new InvalidOperationException("A guarded connection needs a traversable global cut: " +
                        connection.Id);
                Sv5SpaceGatePredicate predicate = Sv5SpaceGatePredicate.FromEdge(edge);
                string routeKey = Sv5SpaceGraphPlanner.RouteKey(connection);
                string boundaryId = "SV5_ROUTE_BOUNDARY_" + RmapWorldDefinition.Hash(connection.Id + "|" +
                    predicate.StableToken + "|" + string.Join(";", faces.Select(value => value.StableToken)))
                    .Substring(0, 20).ToUpperInvariant();
                string[] contactIds = contacts.Where(value =>
                        value.RouteA == routeKey || value.RouteB == routeKey)
                    .Select(value => value.Id).Distinct(StringComparer.Ordinal).OrderBy(value => value,
                        StringComparer.Ordinal).ToArray();
                contactIds = contactIds.Concat(contacts.Where(value =>
                        Sv5SpaceGraphValidator.ValidateBarrierFixture(value, localCells, faces).Count == 0)
                    .Select(value => value.Id)).Distinct(StringComparer.Ordinal)
                    .OrderBy(value => value, StringComparer.Ordinal).ToArray();
                if (contactIds.Length == 0) contactIds = new[] { "ROUTE_SOURCE|" + routeKey };
                RmapSpecialWorldPoint inside = faces.Length == 0 ? localCells[0] :
                    (region.Contains(faces[0].First) ? faces[0].First : faces[0].Second);
                RmapSpecialWorldPoint outside = faces.Length == 0 ? inside :
                    (inside.Equals(faces[0].First) ? faces[0].Second : faces[0].First);
                RmapSpecialWorldPoint sourceAnchor = atSource ? inside : outside;
                RmapSpecialWorldPoint targetAnchor = atSource ? outside : inside;
                return new Sv5SpaceGate("SV5_GATE_" + boundaryId.Substring("SV5_ROUTE_BOUNDARY_".Length),
                    boundaryId, contactIds, localCells, faces,
                    sourceAnchor, targetAnchor,
                    GeometryDirection(sourceAnchor, targetAnchor), connection.Flow,
                    edge.TraversalCondition, predicate, connection.Id, routeKey, connection.FromPortId,
                    connection.ToPortId, Sv5SpaceCrossingKind.ConditionalGate,
                    "SEALED_GLOBAL_WORLD_FACE_CUT_AT_PORT_REGION",
                    "OPEN_RESTORES_GLOBAL_WORLD_FACES");
            }
        }

        internal static IReadOnlyList<Sv5SpaceGateStateCheck> BuildChecks(Sv5CoreReservationPlan core,
            IEnumerable<Sv5SpaceConnection> sourceConnections, IEnumerable<Sv5SpaceGate> sourceGates)
        {
            Sv5SpaceConnection[] connections = (sourceConnections ?? Array.Empty<Sv5SpaceConnection>())
                .Where(value => value != null).ToArray();
            Sv5SpaceGate[] gates = (sourceGates ?? Array.Empty<Sv5SpaceGate>()).Where(value => value != null).ToArray();
            var output = new List<Sv5SpaceGateStateCheck>();
            foreach (Sv5SpaceGate gate in gates)
            {
                Sv5SpaceConnection connection = connections.Single(value => value.Id == gate.SourceConnectionId);
                Add("SEALED_" + gate.Id, gate, connection, 0, false, false, false, false);
                Add("OPEN_" + gate.Id, gate, connection, gate.TypedPredicate.RequiredResourceMask,
                    gate.TypedPredicate.RequiresForge, gate.TypedPredicate.RequiresSeal,
                    gate.TypedPredicate.RequiresBossComplete, true);
            }

            AddWitness("W01_SEAL_ENTRY_REACHABLE", "FORGE_GATED_SEAL_APPROACH", 7, true, false, false, true);
            AddWitness("W02_BOSS_APPROACH_REACHABLE", "SEAL_GATED_BOSS_APPROACH", 7, true, true, false, true);
            AddWitness("W02_EXIT_REMAINS_SEALED", "BOSS_GATED_EXIT_APPROACH", 7, true, true, false, false);
            return new ReadOnlyCollection<Sv5SpaceGateStateCheck>(output.OrderBy(value => value).ToArray());

            void AddWitness(string id, string condition, ulong mask, bool forge, bool seal, bool boss,
                bool expectedOpen)
            {
                Sv5SpaceConnection connection = connections.Single(value => value.Condition == condition);
                Sv5SpaceGate gate = gates.Single(value => value.SourceConnectionId == connection.Id);
                Add(id, gate, connection, mask, forge, seal, boss, expectedOpen);
            }

            void Add(string id, Sv5SpaceGate gate, Sv5SpaceConnection connection, ulong mask, bool forge,
                bool seal, bool boss, bool expectedOpen)
            {
                bool actualOpen = gate.TypedPredicate.IsOpen(mask, forge, seal, boss);
                MovementEvidence sealedEvidence = Explore(core, connections, gates, connection, mask, forge,
                    seal, boss, false);
                MovementEvidence openEvidence = Explore(core, connections, gates, connection, mask, forge,
                    seal, boss, true);
                output.Add(new Sv5SpaceGateStateCheck(id, gate, mask, forge, seal, boss, expectedOpen, actualOpen,
                    sealedEvidence.SourceAnchorReachable, actualOpen ? openEvidence.TargetPortReachable :
                    sealedEvidence.TargetPortReachable, !sealedEvidence.TargetPortReachable,
                    openEvidence.TargetPortReachable, connection.Envelope.Count, gate.BlockingFaces.Count,
                    "accepted-envelope;sealed-cut=" + (!sealedEvidence.TargetPortReachable ? "1" : "0") +
                    ";open-path=" + (openEvidence.TargetPortReachable ? "1" : "0")));
            }
        }

        public static IReadOnlyList<string> FindStateErrors(Sv5CoreReservationPlan core,
            IEnumerable<Sv5SpaceConnection> sourceConnections, IEnumerable<Sv5SpaceGate> sourceGates,
            IEnumerable<Sv5SpaceGateStateCheck> sourceChecks)
        {
            if (core == null) throw new ArgumentNullException(nameof(core));
            Sv5SpaceConnection[] connections = (sourceConnections ?? Array.Empty<Sv5SpaceConnection>())
                .Where(value => value != null).ToArray();
            Sv5SpaceGate[] gates = (sourceGates ?? Array.Empty<Sv5SpaceGate>()).Where(value => value != null).ToArray();
            Sv5SpaceGateStateCheck[] checks = (sourceChecks ?? Array.Empty<Sv5SpaceGateStateCheck>())
                .Where(value => value != null).ToArray();
            var edges = core.RouteSource.Graph.Edges.ToDictionary(value => value.EdgeId, value => value,
                StringComparer.Ordinal);
            var protectedAir = new HashSet<RmapSpecialWorldPoint>(core.CoreCells.Where(value =>
                value.Protection == RmapSpecialProtectionKind.ProtectedAir).Select(value => value.World));
            var globalPassage = new HashSet<RmapSpecialWorldPoint>(connections.SelectMany(value =>
                value.Centerline.Concat(value.ApertureCells)));
            var errors = new List<string>();

            foreach (Sv5SpaceConnection connection in connections.Where(value => value.Kind ==
                         Sv5SpaceConnectionKind.CoreProgression && edges.TryGetValue(value.SourceGraphEdgeId,
                             out RmapWorldGraphEdge edge) && IsGuarded(edge)))
            {
                Sv5SpaceGate[] owned = gates.Where(value => value.SourceConnectionId == connection.Id).ToArray();
                if (owned.Length != 1)
                { errors.Add("GATE_CONNECTION_CARDINALITY|" + connection.Id + "|" + owned.Length); continue; }
                Sv5SpaceGate gate = owned[0];
                if (!gate.TypedPredicate.Equals(Sv5SpaceGatePredicate.FromEdge(edges[connection.SourceGraphEdgeId])))
                    errors.Add("GATE_PREDICATE_EDGE_MISMATCH|" + gate.Id);
                if (gate.SourceRouteId != Sv5SpaceGraphPlanner.RouteKey(connection) ||
                    gate.SourcePortId != connection.FromPortId || gate.TargetPortId != connection.ToPortId)
                    errors.Add("GATE_SOURCE_BINDING_MISMATCH|" + gate.Id);
                if (gate.BlockingFaces.Any(value => !globalPassage.Contains(value.First) ||
                    !globalPassage.Contains(value.Second)))
                    errors.Add("GATE_FACE_OUTSIDE_GLOBAL_PASSAGE|" + gate.Id);
                if (gate.BlockingCells.Any(protectedAir.Contains))
                    errors.Add("GATE_PROTECTED_AIR_STATE_CONFLICT|" + gate.Id);
                MovementEvidence sealedEvidence = Explore(core, connections, gates, connection, 0, false,
                    false, false, false);
                MovementEvidence openEvidence = Explore(core, connections, gates, connection,
                    gate.TypedPredicate.RequiredResourceMask, gate.TypedPredicate.RequiresForge,
                    gate.TypedPredicate.RequiresSeal, gate.TypedPredicate.RequiresBossComplete, true);
                if (!sealedEvidence.SourceAnchorReachable) errors.Add("GATE_SOURCE_PORT_BLOCKED|" + gate.Id);
                if (sealedEvidence.TargetPortReachable) errors.Add("GATE_STATE_SIDE_BYPASS|" + gate.Id);
                if (!openEvidence.TargetPortReachable) errors.Add("GATE_OPEN_PATH_MISSING|" + gate.Id);
            }
            foreach (Sv5SpaceGate gate in gates)
                if (!gate.PlannedBarrierVerified) errors.Add("GATE_GEOMETRY_INVALID|" + gate.Id);
            foreach (Sv5SpaceGateStateCheck check in checks)
                if (!check.Success) errors.Add("GATE_STATE_CHECK_FAILED|" + check.Id);
            foreach (string required in new[]
            {
                "W01_SEAL_ENTRY_REACHABLE", "W02_BOSS_APPROACH_REACHABLE", "W02_EXIT_REMAINS_SEALED",
            })
                if (checks.Count(value => value.Id == required && value.Success) != 1)
                    errors.Add("GATE_REQUIRED_WITNESS_MISSING|" + required);
            errors.AddRange(Sv5SpacePhysicalMovement.FindStateErrors(core, connections, gates));
            return new ReadOnlyCollection<string>(errors.Distinct(StringComparer.Ordinal)
                .OrderBy(value => value, StringComparer.Ordinal).ToArray());
        }

        private static MovementEvidence Explore(Sv5CoreReservationPlan core,
            IEnumerable<Sv5SpaceConnection> sourceConnections, IEnumerable<Sv5SpaceGate> sourceGates,
            Sv5SpaceConnection connection, ulong resourceMask, bool forgeMade, bool sealOpen, bool bossComplete,
            bool? targetOpenOverride)
        {
            Sv5SpaceGate[] targetGate = (sourceGates ?? Array.Empty<Sv5SpaceGate>()).Where(value =>
                value != null && value.SourceConnectionId == connection.Id).ToArray();
            Sv5SpacePhysicalReachability value = Sv5SpacePhysicalMovement.Explore(core, sourceConnections,
                targetGate, connection, resourceMask, forgeMade, sealOpen, bossComplete, targetOpenOverride);
            return new MovementEvidence(value.SourceAnchorReachable, value.TargetPortReachable);
        }

        private static GateCut FullWidthCut(Sv5CoreReservationPlan core, Sv5SpaceConnection connection)
        {
            var accesses = core.Source.Accesses.ToDictionary(value => value.Id, value => value,
                StringComparer.Ordinal);
            var envelope = new HashSet<RmapSpecialWorldPoint>(connection.Envelope);
            var distance = new Dictionary<RmapSpecialWorldPoint, int>();
            var queue = new Queue<RmapSpecialWorldPoint>();
            foreach (RmapSpecialWorldPoint point in accesses[connection.FromPortId].OpenCells.Where(
                         envelope.Contains))
            {
                if (distance.ContainsKey(point)) continue;
                distance.Add(point, 0);
                queue.Enqueue(point);
            }
            while (queue.Count != 0)
            {
                RmapSpecialWorldPoint current = queue.Dequeue();
                foreach (RmapSpecialWorldPoint next in Neighbors(current).Where(envelope.Contains))
                {
                    if (distance.ContainsKey(next)) continue;
                    distance.Add(next, distance[current] + 1);
                    queue.Enqueue(next);
                }
            }
            int targetDistance = accesses[connection.ToPortId].OpenCells.Where(distance.ContainsKey)
                .Select(value => distance[value]).DefaultIfEmpty(-1).Min();
            if (targetDistance < 1)
                throw new InvalidOperationException("A guarded connection needs a reachable target port: " +
                    connection.Id);
            int threshold = Math.Max(0, targetDistance / 2);
            var faces = new List<Sv5SpaceBoundaryFace>();
            RmapSpecialWorldPoint sourceAnchor = default(RmapSpecialWorldPoint);
            RmapSpecialWorldPoint targetAnchor = default(RmapSpecialWorldPoint);
            bool hasAnchor = false;
            foreach (RmapSpecialWorldPoint first in envelope.OrderBy(value => value))
            foreach (RmapSpecialWorldPoint second in Neighbors(first).Where(envelope.Contains))
            {
                if (first.CompareTo(second) >= 0 || !distance.ContainsKey(first) || !distance.ContainsKey(second) ||
                    (distance[first] <= threshold) == (distance[second] <= threshold)) continue;
                faces.Add(new Sv5SpaceBoundaryFace(first, second));
                RmapSpecialWorldPoint source = distance[first] <= threshold ? first : second;
                RmapSpecialWorldPoint target = source.Equals(first) ? second : first;
                if (hasAnchor && !connection.Centerline.Contains(source)) continue;
                sourceAnchor = source;
                targetAnchor = target;
                hasAnchor = true;
            }
            if (!hasAnchor || faces.Count == 0)
                throw new InvalidOperationException("A guarded connection needs a full-width cut: " + connection.Id);
            return new GateCut(faces, sourceAnchor, targetAnchor);
        }

        private static IEnumerable<RmapSpecialWorldPoint> Neighbors(RmapSpecialWorldPoint point)
        {
            if (point.X > 0) yield return new RmapSpecialWorldPoint(point.X - 1, point.Y);
            if (point.X < Sv5SpaceGraphPlanner.WorldWidth - 1) yield return new RmapSpecialWorldPoint(point.X + 1, point.Y);
            if (point.Y > 0) yield return new RmapSpecialWorldPoint(point.X, point.Y - 1);
            if (point.Y < Sv5SpaceGraphPlanner.WorldHeight - 1) yield return new RmapSpecialWorldPoint(point.X, point.Y + 1);
        }

        private static bool IsGuarded(RmapWorldGraphEdge edge) => edge.RequiredResourceMask != 0 ||
            edge.RequiresForge || edge.RequiresSeal || edge.RequiresBossComplete;
        private static string FaceToken(RmapSpecialWorldPoint first, RmapSpecialWorldPoint second) =>
            first.CompareTo(second) <= 0 ? first + ">" + second : second + ">" + first;
        private static RmapWorldGraphDirection GeometryDirection(RmapSpecialWorldPoint first,
            RmapSpecialWorldPoint second) => second.X > first.X ? RmapWorldGraphDirection.Right :
            second.X < first.X ? RmapWorldGraphDirection.Left :
            second.Y > first.Y ? RmapWorldGraphDirection.Up : RmapWorldGraphDirection.Down;

        private sealed class MovementEvidence
        {
            public MovementEvidence(bool sourceAnchorReachable, bool targetPortReachable)
            { SourceAnchorReachable = sourceAnchorReachable; TargetPortReachable = targetPortReachable; }
            public bool SourceAnchorReachable { get; }
            public bool TargetPortReachable { get; }
        }

        private sealed class GateCut
        {
            public GateCut(IEnumerable<Sv5SpaceBoundaryFace> faces, RmapSpecialWorldPoint sourceAnchor,
                RmapSpecialWorldPoint targetAnchor)
            {
                Faces = new ReadOnlyCollection<Sv5SpaceBoundaryFace>(faces.OrderBy(value => value).ToArray());
                SourceAnchor = sourceAnchor;
                TargetAnchor = targetAnchor;
            }
            public IReadOnlyList<Sv5SpaceBoundaryFace> Faces { get; }
            public RmapSpecialWorldPoint SourceAnchor { get; }
            public RmapSpecialWorldPoint TargetAnchor { get; }
        }

    }
}
