#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using StarNight.Map.WorldGeneration.SectorPlanning;
using StarNight.Map.WorldGeneration.SpecialRegions;
using UnityEngine;

namespace StarNight.Map.Tests.EditMode.Sv5
{
    [Category("SV5_06_FIX04")]
    public sealed class Sv5SpaceGraphFix04Tests
    {
        private static readonly Lazy<Sv5CoreReservationPlan> Core = new Lazy<Sv5CoreReservationPlan>(() =>
            Sv5RouteStatePolicyTests.RepresentativePlanForFix01);
        private static readonly Lazy<Sv5SpaceGraphPlan> Plan = new Lazy<Sv5SpaceGraphPlan>(() =>
            Sv5SpaceGraphPlanner.Plan(Core.Value, 1304));

        [Test]
        public void C01_Fix03CounterexampleIsPreserved()
        {
            string path = Path.Combine(Application.dataPath, "..", "MapDesign", "MCP", "INPUTS", "SV5_06_FIX04", "REVIEW_FINDINGS.json");
            Assert.That(File.Exists(path), Is.True, path);
            Assert.That(Plan.Value.GateStateChecks.Count, Is.EqualTo(9));
            foreach (Sv5SpaceGateStateCheck check in Plan.Value.GateStateChecks)
                TestContext.Out.WriteLine($"{check.Id}|expected={check.ExpectedOpen}|actual={check.ActualOpen}|reachable={check.TargetPortReachable}|success={check.Success}|faces={check.CheckedFaces}");
            TestContext.Out.WriteLine("diagnostics=" + string.Join(";", Plan.Value.Diagnostics));
            Assert.That(Plan.Value.GateStateChecks.All(v => v.Success), Is.True);
        }

        [Test] public void F01_ConditionalGatesHaveExactLocalBarriers() {
            Assert.That(Plan.Value.Gates.Count, Is.EqualTo(3));
            Assert.That(Plan.Value.PhysicalMovement.ContactChecks.Where(v => v.Source.Crossing == Sv5SpaceCrossingKind.ConditionalGate).All(v => v.Success), Is.True);
        }
        [Test] public void F02_SharedAndFaceUsePhysicalGeometry() {
            Assert.That(Plan.Value.PhysicalMovement.ContactChecks.Where(v => v.Source.Source.Kind == "SHARED" || v.Source.Source.Kind == "FACE").All(v => v.Success), Is.True);
        }
        [Test] public void F03_DeepStarYeastApproachAndReturnReachable() {
            Assert.That(Plan.Value.PhysicalProduct.Proofs.Count, Is.EqualTo(6));
            Assert.That(Plan.Value.PhysicalProduct.Proofs.All(v => v.Success), Is.True);
        }
        [Test] public void F04_BossForgeClosedPreservesNormalTransitions() {
            Assert.That(Plan.Value.PhysicalProduct.Matrix.All(v => v.Success), Is.True);
        }
        [Test] public void F05_ResourceOrderStateProductIsComplete() {
            Assert.That(Plan.Value.PhysicalProduct.Matrix.Count, Is.GreaterThanOrEqualTo(6));
            Assert.That(Plan.Value.PhysicalProduct.Success, Is.True);
        }
        [Test] public void F06_OptionalCollateralLocksAreAbsent() {
            Assert.That(Plan.Value.Gates.All(v => v.SourceConnectionId.StartsWith("SV5_CORE_CONN_", StringComparison.Ordinal)), Is.True);
            Assert.That(Plan.Value.Connections.Where(v => v.Kind == Sv5SpaceConnectionKind.OptionalBranch)
                .All(c => !Plan.Value.Gates.Any(g => g.SourceConnectionId == c.Id)), Is.True);
        }
        [Test] public void F07_RenameOrderDigestRegression() {
            Assert.That(Plan.Value.PhysicalProduct.SemanticDigest, Is.Not.Empty);
            Assert.That(Plan.Value.PhysicalMovement.SemanticDigest, Is.Not.Empty);
        }
        [Test] public void F08_ExportEvidenceBindsProductDigest() {
            Assert.That(Plan.Value.PhysicalProduct.SemanticDigest, Does.Match("^[0-9a-f]{64}$"));
        }
    }
}
#endif
