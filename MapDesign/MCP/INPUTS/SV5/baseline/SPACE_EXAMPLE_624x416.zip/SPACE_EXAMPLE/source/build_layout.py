"""Authored 624 x 416 tile structure example. No Unity / physics integration.
Coordinates are bottom-left. A=air, S=solid, O=one-way, R=reserved.
Reproducible with Python, numpy. templates.json contains raw authored source cells.
"""
from pathlib import Path
import numpy as np
import json, math, random, heapq, csv
from collections import deque, Counter
from scipy.spatial import cKDTree

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
W,H=624,416
SEED=40921
rng=random.Random(SEED)
world=np.ones((H,W),dtype=np.uint8)
owner=np.zeros((H,W),dtype=np.int16)
locked=np.zeros((H,W),bool)
regions=[];links=[];rooms=[];slots=[];overlays=[];support=set()
source=json.loads((Path(__file__).parent/'templates.json').read_text())

def expand(mask,n=1):
    for _ in range(n):
        p=np.pad(mask,1);h,w=mask.shape
        mask=np.logical_or.reduce([p[y:y+h,x:x+w] for y in range(3) for x in range(3)])
    return mask

def template(kind,w,h):
    return dict(kind=kind,w=w,h=h,base=np.ones((h,w),np.uint8),ports=[],slots=[],overlays=[],rooms=[],routes=[],properties={})

def rect(t,x,y,w,h,val=0):t['base'][y:y+h,x:x+w]=val

def port(t,side,y,hh=3):
    x=0 if side=='L' else t['w']-1
    rect(t,x,y,1,hh)
    t['ports'].append(dict(side=side,x=x,y=y,height=hh))

def core(kind,w=24,h=16):
    t=template(kind,w,h)
    rect(t,3,3,w-6,h-6)
    rect(t,0,3,w,3)
    if kind=='ORE':
        for x,y in [(4,6),(5,8),(17,5),(18,7)]:rect(t,x,y,2,1,1)
        t['slots']=[['ORE_CLUSTER',5,3],['ORE_CLUSTER',17,3]]
    elif kind=='SAP':
        t['slots']=[['SAP_TREE',10,3]]
    elif kind=='YEAST':t['slots']=[['YEAST_GROWTH',8,3],['YEAST_GROWTH',15,3]]
    elif kind=='FORGE':t['slots']=[['FORGE',11,3]]
    elif kind=='START':t['slots']=[['PLAYER',7,3]]
    port(t,'L',3);port(t,'R',3)
    return t

def village():
    t=template('VILLAGE',36,24)
    for side,x,ys in [('L',3,[2,7,12,17]),('R',27,[4,9,14,19])]:
        for i,y in enumerate(ys):
            rect(t,x,y,5,3);t['rooms'].append([x,y,5,3,'HOME_5X3'])
            t['slots'].append(['HOME_TRACE',x+1,y])
            lo,hi=(8,18) if side=='L' else (18,27)
            rect(t,lo,y,hi-lo,2)
            rect(t,lo,y-1,hi-lo,1,2)
            t['slots'].append(['ELEVATOR_STOP',17,y])
    rect(t,17,1,2,22)
    rect(t,0,7,3,3);port(t,'L',7)
    rect(t,32,9,4,3);port(t,'R',9)
    t['properties']={'buildings':8,'interior_size':[5,3],'left_y':[2,7,12,17],'right_y':[4,9,14,19],'elevator':'NOT_IMPLEMENTED','area_vs_24x24':1.5}
    return t

def hub():
    t=template('HUB',24,40)
    rect(t,6,4,12,30)
    for y in (4,14,24):
        rect(t,0,y,6,6);rect(t,18,y,6,6)
        port(t,'L',y,6);port(t,'R',y,6)
    # Central trunk and alternating solid branches: discrete grab targets, not a ladder.
    rect(t,11,4,2,29,1)
    for j,y in enumerate(range(5,32,2)):
        for lo,ww in [(8+(j%2),3-(j%2)),(13,2+(j%2))]:
            rect(t,lo,y,ww,1,1)
            t['overlays'].extend([['TREE_BRANCH',x,y] for x in range(lo,lo+ww)])
    t['overlays'].extend([['TREE_TRUNK',x,y] for x in (11,12) for y in range(4,33)])
    for y in (3,13,23):
        rect(t,0,y,11,1,2);rect(t,13,y,11,1,2)
        rect(t,11,y+1,2,3)
        rect(t,11,y,2,1,2)
    t['properties']={'interior':[12,30],'openings':6,'opening_height':6,'tree_grab_runtime':'NOT_VALIDATED'}
    return t

def jump():
    t=template('JUMP',24,32);rect(t,2,2,20,28)
    rect(t,0,3,8,3);port(t,'L',3)
    # Zigzag course; every ledge is 2 cells wide, empty gaps 3/4, rise 1.
    pts=[(3,3),(8,4),(14,5),(19,6),(14,7),(8,8),(3,9),
         (8,10),(14,11),(19,12),(14,13),(8,14),(3,15),
         (8,16),(14,17),(19,18),(14,19),(8,20),(3,21),
         (8,22),(14,23),(19,24)]
    for x,y in pts:rect(t,x,y-1,2,1,2)
    rect(t,20,24,4,3);port(t,'R',24)
    t['routes']=[dict(id='JUMP_CHALLENGE',points=pts,mode='UNVERIFIED_GAP_3_OR_4_RISE_1')]
    t['properties']={'empty_gap_candidates':[3,4],'rise':1,'runtime':'NOT_VALIDATED','required_progress':False}
    return t

def pinball():
    t=template('PINBALL',24,24)
    for y in range(2,22):
        width=4+round((y-2)/19*6);x=(24-width)//2
        rect(t,x,y,width,1)
    rect(t,0,21,24,2);rect(t,0,20,24,1,2)
    port(t,'L',21,2);port(t,'R',21,2)
    t['slots']=[['PINBALL_NPC',5,21],['PINBALL_BOARD_RESERVED',12,7]]
    t['properties']={'canyon_variant':True,'probability_per_canyon':0.1,'forced_showcase':True,'gameplay':'NOT_IMPLEMENTED'}
    return t

def boss():
    t=template('SEAL_BOSS',36,24)
    rect(t,10,3,25,18);rect(t,0,3,9,3);rect(t,35,3,1,3)
    port(t,'L',3);port(t,'R',3)
    t['slots']=[['SEAL_GATE',9,3],['BOSS',23,3]]
    t['properties']={'gate_cells':[[9,y] for y in (3,4,5)],'gate_state':'CLOSED','required_order':'FORGE -> SEAL -> BOSS -> EXIT'}
    return t

def exitroom():
    t=template('EXIT',12,16);rect(t,2,11,8,4);rect(t,0,11,3,3);port(t,'L',11)
    t['slots']=[['EXIT',7,11]];return t

def place(num,name,x,y,t,color,role='OPTIONAL'):
    t=dict(t);a=np.array(t['base'],np.uint8);h,w=a.shape
    assert not owner[y:y+h,x:x+w].any(),name
    assert x>=0 and y>=0 and x+w<=W and y+h<=H
    world[y:y+h,x:x+w]=a;owner[y:y+h,x:x+w]=num
    imm=(a!=1)|expand(a!=1)
    if role in ('SEALED','RESERVED'):imm[:]=True
    locked[y:y+h,x:x+w]=imm
    r=dict(id=num,name=name,x=x,y=y,w=w,h=h,kind=t['kind'],role=role,color=color,
           ports=[dict(p,id=f'{num:02d}{i}',world=[x+p['x'],y+p['y']]) for i,p in enumerate(t['ports'])],
           properties=t.get('properties',{}),rooms=t.get('rooms',[]),routes=t.get('routes',[]))
    regions.append(r)
    for typ,sx,sy in t['slots']:slots.append(dict(type=typ,x=x+sx,y=y+sy,region=num))
    for typ,sx,sy in t['overlays']:overlays.append(dict(type=typ,x=x+sx,y=y+sy,region=num))
    return r

def raw(kind,variant=None):
    key=kind if variant is None else f'{kind}_{variant}'
    t=dict(source[key]);t['base']=np.array(t['base'],np.uint8)
    t['properties']=dict(t['properties']);t['properties'].pop('fill_plan',None)
    return t

place(1,'시작',36,368,core('START'),'#74c8dd','CORE')
place(2,'광석',144,312,core('ORE'),'#64b8d6','CORE')
place(3,'거친 동굴',204,288,raw('CAVE'),'#98aa83')
place(4,'여섯 갈래길',288,224,hub(),'#85bb6b')
place(5,'대형 도서관',336,296,raw('LIBRARY'),'#aa91cf')
place(6,'토끼 마을',120,192,village(),'#d6b994','CORE')
place(7,'높은 회랑',240,224,raw('HIGH_HALL'),'#d6c784')
place(8,'협곡',300,184,raw('CANYON'),'#c89274')
place(9,'수액',252,264,core('SAP'),'#73b6a0','CORE')
place(10,'효모',324,256,core('YEAST'),'#bd95b1','CORE')
place(11,'핀볼 협곡',504,120,pinball(),'#d6a477')
place(12,'점프맵',360,224,jump(),'#cfb15c')
place(13,'목장',84,72,raw('RANCH'),'#bbbf79')
place(14,'호수',120,64,raw('LAKE'),'#76abc8')
place(15,'철도',180,16,raw('RAIL'),'#bc9c80')
place(16,'농장',240,112,raw('FARM'),'#9db773')
place(17,'절구 작업장 예약',432,48,template('WORKSHOP',36,16),'#88869f','RESERVED')
world[48:64,432:468]=3;locked[48:64,432:468]=True
place(18,'쥐 소굴',312,72,raw('RAT_DEN'),'#9db7a3')
place(19,'제련',492,64,core('FORGE'),'#ce976c','CORE')
place(20,'봉인 · 보스',564,24,boss(),'#c7747a','GATED')
place(21,'출구',600,16,exitroom(),'#79c5d3','GATED')
place(22,'타임 캡슐',240,176,raw('CAPSULE'),'#a399c5','SEALED')
place(23,'감옥',468,224,raw('PRISON'),'#a58298','SEALED')

# Distributed authored rooms across the full world, with local family suppression.
# This is a fixed showcase population, not a production spawn-probability sample.
family_info={
 'CAVE':('거친 동굴','#98aa83',1.0),'CANYON':('협곡','#c89274',1.1),
 'DWELLING':('주거지','#d6b994',1.4),'HIGH_HALL':('높은 회랑','#d6c784',0.9),
 'LIBRARY':('도서관','#aa91cf',1.0),'RAT_DEN':('쥐 소굴','#9db7a3',1.5),
 'LAKE':('호수','#76abc8',0.8),'FARM':('농장','#9db773',0.25),
 'RAIL':('철도','#bc9c80',0.25)}
sectors=[(24+72*x,16+48*y) for y in range(8) for x in range(8)]
rng.shuffle(sectors)
for sx,sy in sectors:
    for passnum in range(2):
        for attempt in range(18):
            weights=[]
            for kind,(_,_,weight) in family_info.items():
                dist=min([math.hypot(sx+36-r['x']-r['w']/2,sy+24-r['y']-r['h']/2) for r in regions if r['kind']==kind] or [999])
                weights.append(weight*(0.015 if dist<90 else 0.12 if dist<150 else 1))
            kind=rng.choices(list(family_info),weights)[0]
            t=raw(kind,rng.randrange(3));w,h=t['w'],t['h']
            x=sx+rng.choice(list(range(0,73-w,12)));y=sy+rng.choice(list(range(0,49-h,8)))
            if owner[max(0,y-4):min(H,y+h+4),max(0,x-4):min(W,x+w+4)].any():continue
            # Keep the three progression sites' outside approaches open.
            if x+w>480 and y<88:continue
            name,color,_=family_info[kind]
            place(len(regions)+1,name,x,y,t,color)
            break
print('Authored places',len(regions))
locked[:1,:]=True;locked[-1:,:]=True;locked[:,:1]=True;locked[:,-1:]=True
initial=world.copy()
byid={r['id']:r for r in regions}

def outside(p):
    x,y=p['world'];return (x+(-1 if p['side']=='L' else 1),y)

def astar(start,goal,valid,step_only=True,limit=45000):
    start=tuple(start);goal=tuple(goal)
    if start==goal:return [start]
    ds=[(-1,0),(1,0),(-1,1),(1,1),(-1,-1),(1,-1)] if step_only else [(1,0),(-1,0),(0,1),(0,-1)]
    def heur(p):return max(abs(p[0]-goal[0]),abs(p[1]-goal[1]))
    q=[(heur(start)*0.7,0,start)];cost={start:0};parent={};count=0
    while q and count<limit:
        _,g,p=heapq.heappop(q)
        if g!=cost.get(p):continue
        count+=1
        if p==goal:
            path=[p]
            while p!=start:p=parent[p];path.append(p)
            return path[::-1]
        x,y=p
        for dx,dy in ds:
            n=(x+dx,y+dy)
            if not (1<=n[0]<W-1 and 1<=n[1]<H-3):continue
            if n!=goal and n!=start and not valid[n[1],n[0]]:continue
            # Mild reuse, no jagged every-cell oscillations if a straight route exists.
            ng=g+(1.15 if world[n[1],n[0]]==1 else 0.7)+(0.13 if dy else 0)
            if ng+1e-8<cost.get(n,1e12):
                cost[n]=ng;parent[n]=p;heapq.heappush(q,(ng+heur(n)*0.7,ng,n))
    return None

# Macro routes avoid all special footprints. Only named ports enter those spaces.
macro_valid=np.zeros((H,W),bool)
for y in range(1,H-3):macro_valid[y,1:W-1]=np.all(owner[y:y+3,1:W-1]==0,axis=0)

def apply_path(path,height=3):
    for i,(x,y) in enumerate(path):
        hh=max(height,3 if (i and path[i-1][1]!=y) or (i+1<len(path) and path[i+1][1]!=y) else 2)
        for yy in range(y,min(H,y+hh)):
            if owner[yy,x]==0 or (not locked[yy,x] and world[yy,x]==1):world[yy,x]=0
        support.add((x,y-1))

def connect(a,b,kind='MAIN',pa=None,pb=None):
    ra,rb=byid[a],byid[b]
    options=[]
    for p in ra['ports']:
        if pa is not None and p['id']!=pa:continue
        for q in rb['ports']:
            if pb is not None and q['id']!=pb:continue
            s,e=outside(p),outside(q)
            options.append((max(abs(s[0]-e[0]),abs(s[1]-e[1])),p,q,s,e))
    for _,p,q,s,e in sorted(options,key=lambda z:z[0]):
        if p['world']==list(e) and q['world']==list(s):path=[tuple(p['world']),tuple(q['world'])]
        else:path=astar(s,e,macro_valid)
        if not path:continue
        apply_path(path)
        full=[tuple(p['world'])]+path+[tuple(q['world'])]
        links.append(dict(id=f'C{len(links)+1:03d}',a=a,b=b,port_a=p['id'],port_b=q['id'],kind=kind,points=full,length=len(full)-1,movement='STATIC_INTENT_NOT_PHYSICS_VALIDATED'))
        return True
    return False

# Six separate neighboring destinations, one per actual hub opening.
hub_targets=[(7,'040'),(9,'041'),(3,'044'),(10,'042'),(5,'045'),(12,'043')]
# Ports order is L low / R low / L mid / R mid / L high / R high.
hub_targets=[(7,'040'),(9,'042'),(3,'044'),(10,'041'),(5,'045'),(12,'043')]
for dest,p in hub_targets:
    ok=connect(4,dest,'HUB',pa=p)
    if not ok:print('HUB_ROUTE_PENDING',dest,p)

# A connected public district, followed by additional cycles for meaningful rejoining.
public=[r['id'] for r in regions if r['role'] not in ('SEALED','GATED','RESERVED')]
groups={i:i for i in public}
def root(i):
    while groups[i]!=i:i=groups[i]
    return i
def union(a,b):groups[root(a)]=root(b)
for e in links:union(e['a'],e['b'])
candidates=[]
for i,a in enumerate(public):
    for b in public[i+1:]:
        ra,rb=byid[a],byid[b]
        d=min(max(abs(p['world'][0]-q['world'][0]),abs(p['world'][1]-q['world'][1])) for p in ra['ports'] for q in rb['ports'])
        candidates.append((d,a,b))
for d,a,b in sorted(candidates):
    if root(a)!=root(b) and connect(a,b):union(a,b)
for a,b in [(1,3),(2,6),(6,7),(7,14),(14,18),(18,16),(16,12),(12,5),(9,10),(8,11),(11,12),(13,14),(13,15),(15,19),(3,5)]:
    if not any({e['a'],e['b']}=={a,b} for e in links):connect(a,b,'REJOIN')
extra=0
for d,a,b in sorted(candidates,key=lambda z:z[0]+rng.random()*15):
    if not 18<=d<=65:continue
    if any({e['a'],e['b']}=={a,b} for e in links):continue
    if sum(a in (e['a'],e['b']) for e in links)>=4 or sum(b in (e['a'],e['b']) for e in links)>=4:continue
    if connect(a,b,'REJOIN'):extra+=1
    if extra>=55:break
assert connect(19,20,'PROGRESSION_GATE')
assert connect(20,21,'BOSS_EXIT')
print('Primary links',len(links),'public components',len({root(i) for i in public}))
anchor_points=[]
for e in links:
    if e['kind']=='BOSS_EXIT':continue
    anchor_points.extend(tuple(p) for p in e['points'][1:-1:2] if owner[p[1],p[0]]==0)
anchor_points=list(set(anchor_points));anchor_tree=cKDTree(anchor_points)

# Ordinary spaces live in the rock left between authored structures. Preserve all
# original room contacts and shelves. Dividing residual mass creates spaces, not
# unbounded exterior AIR or isolated one-pixel holes.
def valid_pocket(x,y,w,h):
    if not (1<=x and 1<=y and x+w<=W-1 and y+h<=H-1):return False
    return not locked[y:y+h,x:x+w].any() and np.all(world[y:y+h,x:x+w]==1)

def carve_room(x,y,w,h,kind='ORDINARY'):
    world[y:y+h,x:x+w]=0
    room=dict(id=f'N{len(rooms)+1:03d}',x=x,y=y,w=w,h=h,kind=kind)
    rooms.append(room)
    for xx in range(x,x+w):support.add((xx,y-1))
    return room

# Irregularly staggered small galleries / empty utility rooms. Not a repeated biome.
for gy in range(3,H-4,7):
    for gx in range(3,W-5,11):
        choices=[]
        for _ in range(10):
            x=gx+rng.randint(-2,2);y=gy+rng.randint(-1,1)
            w=rng.choice([5,6,7,8]);h=rng.choice([3,3,4,5])
            if valid_pocket(x,y,w,h):choices.append((x,y,w,h))
        if choices:carve_room(*rng.choice(choices))

def ordinary_valid():
    free=~locked | (world!=1)
    # All named interiors, including their air, are excluded from new side entrances.
    free[locked]=False
    valid=np.zeros_like(free)
    valid[:-3,:]=free[:-3,:]&free[1:-2,:]&free[2:-1,:]
    # Existing macro corridor is okay; do not open new ports on a structure.
    valid[(owner==0)&(world==0)]=True
    return valid

# Attach pockets to an already public passage, or another ordinary pocket. The
# centerline has 2-cell passages; inclines receive 3-cell clearance.
attach_fail=[]
for room_index,room in enumerate(rooms):
    x,y,w,h=(room[k] for k in ('x','y','w','h'))
    s=(x+w//2,y)
    valid=ordinary_valid()
    ds,idx=anchor_tree.query(s,k=32,p=np.inf)
    candidates=[(float(d),anchor_points[int(i)]) for d,i in zip(ds,idx)]
    path=None
    for _,goal in candidates:
        path=astar(s,goal,valid,limit=12000)
        if path:break
    if path:
        apply_path(path,2)
        room['connection']=path
        anchor_points.extend(path[::2])
    else:attach_fail.append(room['id'])
    if room_index%25==24:
        anchor_points=list(set(anchor_points));anchor_tree=cKDTree(anchor_points)
    if room_index%400==0:print('Ordinary attachment',room_index,'/',len(rooms),flush=True)

# Broad pockets in remaining large solid masses. Every cut is a 3x2 or wider room;
# no single-pixel holes. Some alcoves stay closed as visibly flagged draft debt.
def six_windows():
    s=np.pad((world==1).astype(np.int32),((1,0),(1,0))).cumsum(0).cumsum(1)
    return s[6:,6:]-s[:-6,6:]-s[6:,:-6]+s[:-6,:-6]==36

for iteration in range(3000):
    bad=np.argwhere(six_windows())
    if not len(bad):break
    placed=False
    for yy,xx in bad:
        choices=[]
        for ww,hh in [(5,3),(4,3),(3,2),(2,3)]:
            for dy in range(6-hh+1):
                for dx in range(6-ww+1):
                    x=int(xx)+dx;y=int(yy)+dy
                    if valid_pocket(x,y,ww,hh):choices.append((x,y,ww,hh))
            if choices:break
        if choices:
            x,y,ww,hh=choices[len(choices)//2]
            if valid_pocket(x,y,ww,hh):
                rr=carve_room(x,y,ww,hh,'RESIDUAL_ALCOVE')
                valid=ordinary_valid();s=(x+ww//2,y)
                ds,idx=anchor_tree.query(s,k=32,p=np.inf)
                near=[(float(d),anchor_points[int(i)]) for d,i in zip(ds,idx)]
                path=None
                for _,goal in near[:35]:
                    path=astar(s,goal,valid,limit=8000)
                    if path:break
                if path:apply_path(path,2);rr['connection']=path
                else:attach_fail.append(rr['id'])
                if path:anchor_points.extend(path[::2])
                placed=True
        if placed:break
    if not placed:break
    if iteration%25==24:
        anchor_points=list(set(anchor_points));anchor_tree=cKDTree(anchor_points)
    if iteration%100==0:print('Residual rooms',iteration,'solid windows',len(bad),flush=True)

# Supports at shared passage crossings become one-way rather than solid plugs.
for x,y in support:
    if 0<=x<W and 0<=y<H and not locked[y,x] and world[y,x]==0:world[y,x]=2

# Flood check is about cell topology only. It is not jump/grab/elevator validation.
def flood(a,start):
    seen=set();q=deque([start]);seen.add(start)
    while q:
        x,y=q.popleft()
        for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            p=(x+dx,y+dy)
            if 0<=p[0]<W and 0<=p[1]<H and a[p[1],p[0]] in (0,2) and p not in seen:seen.add(p);q.append(p)
    return seen

seen=flood(world,(43,371))
opened=world.copy()
for x,y in byid[20]['properties']['gate_cells']:opened[24+y,564+x]=0
seen_open=flood(opened,(43,371))
def in_reach(num,reached):
    r=byid[num];return any((x,y) in reached for y in range(r['y'],r['y']+r['h']) for x in range(r['x'],r['x']+r['w']) if initial[y,x]==0)
bad=six_windows();badloc=[[int(x),int(y)] for y,x in np.argwhere(bad)]
validation=dict(size=[W,H],seed=SEED,tile_counts={k:int(np.sum(world==i)) for i,k in enumerate(['AIR','SOLID','ONE_WAY','RESERVED'])},
    regions=len(regions),ordinary_rooms=len(rooms),ordinary_attachments_pending=len(attach_fail),
    public_graph_components=len({root(i) for i in public}),named_connections=len(links),
    closed_gate_reachable_regions=[r['id'] for r in regions if in_reach(r['id'],seen)],
    public_regions_not_reached=[i for i in public if not in_reach(i,seen)],
    exit_closed_gate_reachable=in_reach(21,seen),exit_open_gate_reachable=in_reach(21,seen_open),
    type0_publicly_reached=[i for i in (22,23) if in_reach(i,seen)],
    solid_6x6_windows=int(bad.sum()),solid_6x6_locations=badloc,
    contact_shell_modified=int(np.sum((world!=initial)&locked)),
    physics='NOT_RUN',runtime='NOT_IMPLEMENTED',scope='AUTHORED_624x416_EXAMPLE_NOT_UNITY_BAKE',
    pending=['Jump/grab trajectories','Tree ascent','Elevator no-crush logic','Library contact stairs and Down key','Spawn distribution','Production role/biome integration'])
validation['hub_distinct_neighbors']=len({e['b'] if e['a']==4 else e['a'] for e in links if 4 in (e['a'],e['b'])})
validation['hub_openings_used']=sorted({e['port_a'] if e['a']==4 else e['port_b'] for e in links if 4 in (e['a'],e['b'])})
np.savez_compressed(DATA/'world.npz',world=world,owner=owner,locked=locked,initial=initial)
for name,obj in [('regions',regions),('connections',links),('ordinary_rooms',rooms),('slots',slots),('overlays',overlays),('validation',validation)]:
    (DATA/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
with (DATA/'world_cells.csv').open('w',newline='',encoding='utf8') as f:
    out=csv.writer(f);out.writerow(['x','y','cell','region'])
    out.writerows((x,y,'ASOR'[world[y,x]],int(owner[y,x])) for y in range(H) for x in range(W))
print(json.dumps({k:v for k,v in validation.items() if k!='solid_6x6_locations'},ensure_ascii=False,indent=2))
