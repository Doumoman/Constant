"""Render exact tile data to annotated PNGs and a zoomable review PDF.
Decorations are illustrative non-collision slots, not Unity assets.
"""
from pathlib import Path
import json,math,io,csv,zipfile,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageColor
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
import fitz

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT.parent;DATA=ROOT/'data'
F=Path(__file__).parent
fontpath=F/'Korean.ttf'
if not fontpath.exists():fontpath.write_bytes(fitz.Font('korea').buffer)
KR=str(fontpath);SANS='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('KR',KR));pdfmetrics.registerFont(TTFont('Sans',SANS));pdfmetrics.registerFont(TTFont('Bold',BOLD))
world=np.load(DATA/'world.npz')['world'];H,W=world.shape
owner=np.load(DATA/'world.npz')['owner']
regions=json.loads((DATA/'regions.json').read_text());byid={r['id']:r for r in regions}
slots=json.loads((DATA/'slots.json').read_text());overlays=json.loads((DATA/'overlays.json').read_text())
links=json.loads((DATA/'connections.json').read_text());checks=json.loads((DATA/'validation.json').read_text())
T=10
PAPER='#f1f0e8';INK='#24383d';MUTED='#52656a';AIR=(23,36,43);STONE=(122,136,132)
cache={}
def font(sz,kind='kr'):
    key=(sz,kind)
    if key not in cache:cache[key]=ImageFont.truetype(KR if kind=='kr' else BOLD if kind=='bold' else SANS,max(1,int(sz)))
    return cache[key]
def mix(a,b,t):return tuple(round(x*(1-t)+y*t) for x,y in zip(a,b))
def rgb(c):return ImageColor.getrgb(c)
def xy(x,y):return (x*T,(H-y)*T)
def cellbox(x,y):return (x*T,(H-y-1)*T,(x+1)*T-1,(H-y)*T-1)

# Fill is actual collision data; one-way tiles are drawn as a thin top edge.
pal=np.zeros((H,W,3),np.uint8)
bg=np.zeros((len(regions)+1,3),np.uint8);bg[0]=AIR
for r in regions:bg[r['id']]=mix(AIR,rgb(r['color']),0.17)
for y in range(H):
    for x in range(W):
        v=world[y,x]
        if v==1:
            noise=((x*19+y*31)%7-3)*1.2
            pal[y,x]=tuple(max(0,min(255,round(c+noise))) for c in STONE)
        elif v==3:pal[y,x]=(69,65,87)
        else:pal[y,x]=bg[owner[y,x]]
im=Image.fromarray(pal[::-1]).resize((W*T,H*T),Image.Resampling.NEAREST)
d=ImageDraw.Draw(im)

for y in range(H):
    for x in range(W):
        b=cellbox(x,y);v=world[y,x]
        if v==1:
            d.line((b[0],b[3],b[2],b[3]),fill=(105,119,117),width=1)
            if y+1<H and world[y+1,x] in (0,2):d.line((b[0],b[1],b[2],b[1]),fill=(185,191,163),width=2)
            if x and world[y,x-1]==0:d.line((b[0],b[1],b[0],b[3]),fill=(143,156,146),width=1)
        elif v==2:
            d.rectangle((b[0],b[1]+1,b[2],b[1]+2),fill=(222,186,117))
        elif v==3 and (x+y)%3==0:
            d.line((b[0],b[3],b[2],b[1]),fill=(133,124,160),width=1)

# Non-collision book stacks, columns, dwellings and character/object slots.
def boxf(x,y,w,h,fill,outline=None,width=1):
    d.rectangle((x*T,(H-y-h)*T,(x+w)*T,(H-y)*T),fill=fill,outline=outline,width=width)
def person(x,y,col=(222,218,191),sz=1):
    # All ordinary humanoids use the 0.4 x 0.8 tile reference footprint.
    boxf(x+.3,y,.4*sz,.5*sz,col)
    d.ellipse((int((x+.3)*T),int((H-y-.8*sz)*T),int((x+.7*sz)*T),int((H-y-.45*sz)*T)),fill=col)
for s in slots:
    typ,x,y=s['type'],s['x'],s['y']
    if typ=='BG_BOOKCASE':
        hh=.8 if y+1>=H or world[y+1,x]==1 else 1.7
        boxf(x+.08,y+.08,1.8,hh,(54,56,73))
        for off,col in [(.3,(80,81,93)),(.7,(92,79,88)),(1.15,(75,84,103)),(1.5,(84,91,98))]:boxf(x+off,y+.25,.18,min(1.2,hh-.2),col)
        boxf(x+.06,y+.15,1.84,.1,(108,91,101))
    elif typ=='BG_COLUMN':boxf(x+.1,y,.8,1,(71,76,75))
    elif typ=='CHANDELIER':
        r=byid[s['region']];top=r['y']+r['properties'].get('clear_height',17)
        d.line((xy(x+.5,top),xy(x+.5,y+.7)),fill=(156,145,100),width=2)
        boxf(x-1.6,y,4.2,.3,(181,160,94))
        for dx in (-1.2,0,1.2):boxf(x+dx,y+.3,.45,.6,(243,218,132))
    elif typ=='HOME_TRACE':
        boxf(x,y,2,.35,(168,137,117));boxf(x,y+.35,.55,.25,(207,196,160))
    elif typ.startswith('ELEVATOR_STOP'):
        boxf(x,y-.2,1.8,.15,(116,185,178))
    elif typ=='CROP':
        d.line((xy(x+.5,y),xy(x+.5,y+.9)),fill=(152,184,98),width=2)
        d.line((xy(x+.1,y+.7),xy(x+.5,y+.4),xy(x+.9,y+.8)),fill=(152,184,98),width=2)
    elif typ=='FENCE':
        boxf(x+.2,y,.12,1,(123,119,84));boxf(x,y+.6,1.5,.1,(123,119,84))
    elif typ=='DECOR_ANIMAL':
        boxf(x,y,.9,.45,(203,200,169));boxf(x+.7,y+.25,.35,.4,(203,200,169))
    elif typ in ('SHEPHERD_NPC','PINBALL_NPC'):person(x,y,(214,198,137))
    elif typ=='PLAYER':person(x,y,(101,229,237))
    elif typ=='HIDDEN_SILHOUETTE':person(x,y,(119,97,133))
    elif typ=='TRAIN_START':
        boxf(x-1,y,2,.8,(174,138,101));boxf(x-.7,y+.8,1.4,.3,(106,127,128))
    elif typ in ('CHEST','LETTER'):
        boxf(x,y,.85,.6,(197,166,107) if typ=='CHEST' else (210,208,173))
    elif typ=='BREAKABLE_ACCESS_WALL':
        d.line((xy(x+.7,y),xy(x+.3,y+.45),xy(x+.6,y+1)),fill=(192,128,203),width=2)
    elif typ=='ORE_CLUSTER':
        for dx in (0,.6,1.2):boxf(x+dx,y,.5,.7,(91,181,209))
    elif typ=='SAP_TREE':
        boxf(x,y,1,5,(95,145,121));boxf(x-1,y+3,3,.5,(117,163,124))
    elif typ=='YEAST_GROWTH':
        boxf(x,y,1,.45,(194,139,174));boxf(x+.6,y,1,.75,(178,127,164))
    elif typ=='FORGE':
        boxf(x,y,2,1,(126,122,117));boxf(x+.5,y+1,1,.8,(230,149,76))
    elif typ=='SEAL_GATE':
        boxf(x,y,1,3,(191,94,105));d.line((xy(x+.5,y),xy(x+.5,y+3)),fill=(246,186,148),width=2)
    elif typ=='BOSS':person(x,y,(194,96,111),sz=2.7)
    elif typ=='EXIT':
        boxf(x,y,1.3,2.2,(59,111,122),(117,213,216),2)
    elif typ=='PINBALL_BOARD_RESERVED':
        for dy in range(0,9,2):
            for dx in (-1,1):
                xx,yy=xy(x+dx+.5,y+dy+.5);d.ellipse((xx-1,yy-1,xx+1,yy+1),fill=(171,166,115))

# Collision platforms must remain visible above non-colliding bookshelf art.
for y,x in zip(*np.where(world==2)):
    b=cellbox(int(x),int(y));d.rectangle((b[0],b[1]+1,b[2],b[1]+2),fill=(222,186,117))

for o in overlays:
    typ,x,y=o['type'],o['x'],o['y'];b=cellbox(x,y)
    if typ=='WATER':
        d.rectangle(b,fill=(44,110,139))
        d.line((b[0],b[1],b[2],b[1]),fill=(67,147,170))
    elif typ.startswith('TREE'):
        if world[y,x]==1:
            d.rectangle(b,fill=(107,143,91) if typ=='TREE_BRANCH' else (101,120,79))
            d.line((b[0]+3,b[1],b[0]+3,b[3]),fill=(82,104,73),width=1)
        elif world[y,x]==0:
            d.line((b[0]+4,b[1],b[0]+4,b[3]),fill=(53,73,53),width=1)
    elif typ=='DIAGONAL_STEP':
        d.line((b[0],b[1]+1,b[2],b[1]+1),fill=(220,180,242),width=2)
for r in regions:
    nodes=r['properties'].get('rail_nodes',[])
    if nodes:
        pts=[xy(r['x']+x+.5,r['y']+y-.12) for x,y in nodes]
        d.line(pts,fill=(193,150,104),width=2)

raw=im.copy();raw.save(ROOT/'tile_map.png')

# Numbered review markers sit on the upper edge of the footprint. No region boxes
# in the terrain version, so adjacent structures read as one continuous landscape.
def labels(image):
    dr=ImageDraw.Draw(image)
    for r in regions:
        x=r['x']*T+3;y=(H-r['y']-r['h'])*T+3
        title=f"#{r['id']:03d}";ff=font(11,'bold');bb=dr.textbbox((0,0),title,font=ff)
        ww=bb[2]+8;hh=16
        dr.rounded_rectangle((x,y,x+ww,y+hh),radius=3,fill=(23,35,42),outline=rgb(r['color']),width=1)
        dr.text((x+4,y+1),title,font=ff,fill=rgb(r['color']))
    return image
numbered=labels(im.copy());numbered.save(ROOT/'tile_map_numbered.png')

def crop_region(image,bounds):
    x,y,w,h=bounds;return image.crop((x*T,(H-y-h)*T,(x+w)*T,(H-y)*T))

def make_poster(image,path,title,subtitle,foot):
    margin=90;head=210;bottom=100
    dest=Image.new('RGB',(image.width+2*margin,image.height+head+bottom),PAPER)
    dr=ImageDraw.Draw(dest)
    dr.text((margin,43),title,font=font(68),fill=INK)
    dr.text((margin,135),subtitle,font=font(31),fill=MUTED)
    dest.paste(image,(margin,head))
    dr.text((margin,head+image.height+30),foot,font=font(27),fill=MUTED)
    dest.save(path)
    return dest

overview_path=OUT/'SPACE_EXAMPLE_624x416.png'
make_poster(numbered,overview_path,'마펠렁키  |  624 × 416 타일 전체 배치',
            '259,584칸 · 52 × 52 마이크로 청크 · 101개 장소 · 지형과 통로가 이어진 구조 예시',
            '밝은 회색 = 지형  /  어두운 공간 = 내부  /  금색 선 = 발판  /  보라색 사선 = 예약  |  번호로 피드백 가능 · Unity 이동 검증 전')

# A single actual crop, not a separately authored prettier example.
detail_bounds=(228,176,168,160)
detail=crop_region(numbered,detail_bounds).resize((2520,2400),Image.Resampling.NEAREST)
detail_path=OUT/'SPACE_EXAMPLE_DETAIL.png'
make_poster(detail,detail_path,'중앙 구역 확대',
            '전체 지도에서 그대로 잘라낸 구간 · x 228–395 / y 176–335',
            '#004 계수나무 허브 · #005 도서관 · #007 높은 회랑 · #008 협곡 · #012 점프맵')

# Route inspection overlay distinguishes intent lines from actual collision cells.
routeim=numbered.copy();layer=Image.new('RGBA',routeim.size,(0,0,0,0));rd=ImageDraw.Draw(layer)
for e in links:
    col=(230,182,99,175) if e['kind']=='REJOIN' else (112,218,224,170)
    if e['kind'] in ('PROGRESSION_GATE','BOSS_EXIT'):col=(236,129,142,220)
    pts=[xy(x+.5,y+.5) for x,y in e['points']]
    rd.line(pts,fill=col,width=3)
routeim=Image.alpha_composite(routeim.convert('RGBA'),layer).convert('RGB')
routeim.save(ROOT/'route_map.png')

# PDF: whole map, zoom index, connected center, 16 full-resolution quadrants,
# then an index and a short, candid verification page.
pdfpath=OUT/'SPACE_EXAMPLE_624x416.pdf'
PW,PH=landscape(A3);c=canvas.Canvas(str(pdfpath),pagesize=(PW,PH),pageCompression=1)
c.setTitle('마펠렁키 624×416 전체 타일 구조 예시');c.setAuthor('Map design review')
page_no=0
def txt(x,y,s,size=10,col=INK,ft='KR'):
    c.setFillColor(col);c.setFont(ft,size);c.drawString(x,y,s)
def begin(title,sub):
    global page_no
    page_no+=1;c.setFillColor(PAPER);c.rect(0,0,PW,PH,fill=1,stroke=0)
    txt(25,PH-29,title,19)
    txt(25,PH-46,sub,9,MUTED)
    txt(PW-70,PH-28,f'{page_no:02d}',10,MUTED,'Sans')
def end(note='설계용 정적 타일 예시 · Unity 씬/점프·매달리기·동적 장치 검증 전'):
    txt(25,16,note,8,MUTED);c.showPage()
def full_map(image):
    iw,ih=image.size;maxw=PW-50;maxh=PH-82
    scale=min(maxw/iw,maxh/ih);ww=iw*scale;hh=ih*scale
    c.drawImage(ImageReader(image),25+(maxw-ww)/2,31,width=ww,height=hh)
    return (25+(maxw-ww)/2,31,ww,hh)

begin('624 × 416 — 전체 타일 배치','번호 #001–#101은 장소 ID. 작은 방·굴·연결 지점은 지형의 일부로 구성했다. 빈 외부 AIR로 둘러싼 배치가 아니다.')
full_map(numbered);end()

begin('확대도 찾아보기 — A1부터 D4까지','다음 16개 구간은 각각 156 × 104칸. 전체 지도와 같은 셀을 확대한다. 시안의 고정 배치이며 스폰 확률 표본은 아니다.')
xx,yy,ww,hh=full_map(numbered)
for j in range(4):
    for i in range(4):
        x=xx+i*ww/4;y=yy+(3-j)*hh/4
        c.setStrokeColor('#d6ece9');c.setLineWidth(.8);c.rect(x,y,ww/4,hh/4,fill=0,stroke=1)
        c.setFillColor('#24383d');c.rect(x+3,y+hh/4-29,44,24,fill=1,stroke=0)
        txt(x+9,y+hh/4-23,f'{"ABCD"[j]}{i+1}',16,'#f1f0e8','Bold')
end('좌표 원점은 왼쪽 아래. A행은 y 312–415, D행은 y 0–103이다.')

begin('중앙 연결 구역 — 서로 다른 장소가 한 지형으로 이어지는가','허브·도서관·회랑·협곡·점프맵과 그 사이의 보조 공간을 함께 보는 구간. x 228–395 / y 176–335')
ci=crop_region(numbered,detail_bounds)
scale=(PH-90)/ci.height;dw=ci.width*scale
c.drawImage(ImageReader(ci),25,31,width=dw,height=ci.height*scale)
sx=dw+49;yy=PH-91
notes=[('004 여섯 갈래길','12×30 내부 / 좌우 3단 출입구', '계수나무 가지 간격은 2칸.', '실제 매달림·등반은 검증 전.'),
       ('005 대형 도서관','20×25 열린 내부 / 책장 배경','층간 3–5칸 / 대각선 발판 계단','접촉 상승·아래키 하강은 구현 전.'),
       ('007 높은 회랑','높이 17칸의 큰 실내 공간','샹들리에와 기둥은 배경 장식.','통로와 대비되는 크기를 확인.'),
       ('008 협곡','상부 약 10칸 → 하부 약 4칸','벽 덩어리가 아래로 차오르는 형상.','아래쪽 낙하 회복 경로는 검증 전.'),
       ('012 점프맵','단계마다 +1칸 / 후보 간격 3–4칸','금색 선은 위쪽 판정 발판.','큰 간격은 점프 성공 보장 없음.'),
       ('연결 통로','작은 빈 방과 굴이 사이를 채운다.','필수 진행과 별개로 돌아갈 길 존재.','외곽은 위 전체도에서 확인.')]
for lines in notes:
    txt(sx,yy,lines[0],12);yy-=20
    for line in lines[1:]:txt(sx,yy,line,10,MUTED);yy-=17
    yy-=26
end()

for j in range(4):
    for i in range(4):
        x=i*156;y=(3-j)*104;ident=f'{"ABCD"[j]}{i+1}'
        begin(f'{ident} — 타일 확대도',f'x {x}–{x+155} / y {y}–{y+103} · 각 칸은 1×1 · 마이크로 청크 경계 12×8칸은 옅은 선')
        ci=crop_region(numbered,(x,y,156,104));dr=ImageDraw.Draw(ci,'RGBA')
        for gx in range(x,x+157):
            if gx%12==0:dr.line(((gx-x)*T,0,(gx-x)*T,104*T),fill=(188,210,209,30),width=1)
        for gy in range(y,y+105):
            if gy%8==0:dr.line((0,(y+104-gy)*T,156*T,(y+104-gy)*T),fill=(188,210,209,30),width=1)
        full_map(ci);end(f'{ident} 구간 · 장소 번호 또는 (x, y) 좌표로 수정할 부분을 지정할 수 있다.')

begin('통로 연결 확인용 전체도','청록 = 연결 의도 / 금색 = 추가 재합류 / 붉은색 = 진행 구역 연결. 선 자체는 통과 판정이나 점프 성공을 뜻하지 않는다.')
full_map(routeim);end()

# Compact 101-item index in four columns, with sector references.
begin('장소 번호표','각 장소의 왼쪽 아래 위치. 일반 보조 방·샛길은 별도 공간 ID를 데이터에 보관했다.')
colw=(PW-50)/4
for k,r in enumerate(regions):
    col=k//26;row=k%26;xx=25+col*colw;yy=PH-75-row*27
    i=min(3,int((r['x']+r['w']/2)//156));j=min(3,3-int((r['y']+r['h']/2)//104));sector=f'{"ABCD"[j]}{i+1}'
    txt(xx,yy,f"#{r['id']:03d}",10,INK,'Bold')
    txt(xx+39,yy,r['name'],10)
    txt(xx+39,yy-11,f"{sector} · ({r['x']}, {r['y']}) · {r['w']}×{r['h']}",8,MUTED,'Sans')
end()

begin('이 시안에서 확인한 것 / 다음에 확인할 것','실제 셀 합성 결과와 플레이 구현 상태를 구분한다. 이 PDF는 Unity 실행 결과가 아니다.')
left=28;right=PW/2+20;yy=PH-90
txt(left,yy,'셀 데이터로 확인',16);txt(right,yy,'아직 플레이 보증하지 않음',16)
ok=[
 '624×416 = 259,584셀. 12×8 마이크로 청크 52×52개.',
 '101개 장소를 원래 타일 크기로 배치. 216×144 지도 확대 복사가 아님.',
 '공개 장소 그래프 1개. 일반 통로의 셀 연결에서 고립된 장소 0개.',
 '계수나무 허브의 좌우 6개 출입구를 모두 연결.',
 '전체 슬라이딩 검사에서 완전히 SOLID인 6×6 구간 0개.',
 '기존 내부와 맞닿은 충돌면 보존. 보호 셀 변경 0개.',
 '봉인 문을 닫으면 출구 접근 불가, 문 셀을 열면 연결됨.',
 '타임 캡슐·감옥은 일반 셀 통로로 접근되지 않음.',
 '절구 작업장 36×16 = 576셀은 RESERVED로 유지.',
 '주요 장소 101개 외에 작은 방·굴·틈을 연결해 외곽 덩어리를 분할.',
    f"방을 파낸 {checks['ordinary_rooms']:,}회는 독립된 최종 방 수가 아님. 일부는 통로와 합쳐짐."
]
todo=[
 '셀 연결 검사는 발판·물·점프 물리를 포함하지 않는다.',
 '최대 2칸 상승 규칙으로 전 구간 무아이템 완주를 아직 입증하지 못함.',
 '일반 경사는 한 칸 상승 의도. 머리 여유·착지·매달림 재검증 필요.',
 '점프맵의 가로 3–4칸 간격은 후보값. 실패 구간은 조정해야 함.',
 '나무 등반, 엘리베이터의 압사 방지, 발판 계단 이동은 구현 전.',
 '도서관의 배경 책장·회랑 기둥·동물 등은 충돌 없는 장식 슬롯.',
 '핀볼·기차 탈선·호수 행동·감옥 생명체는 구현하지 않음.',
 '핵심 장소는 진행 역할의 공간 예시. RMAP15 정본 통합 전.',
 '광석·수액·효모 획득 순서, 제련·봉인·보스 상태 검증은 별도.',
 '희귀 장소를 보여주기 위해 고정 배치. 생산용 스폰 확률 결과 아님.',
 '봉인 검사는 닫힌 문과 열린 문의 정적 비교. 동적 상태 머신 아님.'
]
for col,lines in [(left,ok),(right,todo)]:
    yy=PH-128
    for s in lines:
        txt(col,yy,s,10);yy-=32
yy=160
txt(left,yy,'검토 포인트',15)
for j,line in enumerate(['1. 장소들이 하나의 이어진 지형으로 읽히는가?',
                         '2. 큰 공간 / 좁은 통로 / 평범한 방의 리듬이 적당한가?',
                         '3. 돌아가는 길과 지름길 후보가 과하거나 부족한 구간은 어디인가?',
                         '4. 마음에 들지 않는 곳은 페이지 구간(A1–D4)과 장소 번호로 지정.']):txt(left,yy-26-j*23,line,11)
end('이 예시는 시각 검토용 설계 산출물이며 최종 런타임 합격 판정이 아니다.')
c.save()

readme=f'''# 마펠렁키 624×416 전체 타일 예시

사용자 피드백에 따라 작은 시범 구역을 늘려 그린 것이 아니라 **624×416 좌표 공간**에 101개 장소와 일반 구조를 재배치한 정적 설계 예시입니다.

## 보는 방법
- `SPACE_EXAMPLE_624x416.pdf`: 전체도, 구간 색인, 중앙 확대, A1–D4의 16개 확대도, 통로 확인도, 장소 색인, 검증 범위.
- `SPACE_EXAMPLE_624x416.png`: 전체 지도. `SPACE_EXAMPLE_DETAIL.png`: 동일 데이터의 중앙 구역 확대.
- `data/world_cells.csv`: x,y,cell,region. 원점은 왼쪽 아래. A=air / S=solid / O=one-way / R=reserved.
- `data/regions.json`: 장소 ID·크기·출입구·설계 속성. `connections.json`: 연결 의도 중심선.
- `data/ordinary_rooms.json`: 작은 방을 파낸 기록. 합쳐진 공간이 있으므로 항목 수를 최종 방 수로 해석하지 않습니다.
- `data/validation.json`: 전체 셀 검사. 점프 성공·무아이템 완주·상태 머신 검증은 포함하지 않습니다.

## 범위
전체 {W}×{H} = {W*H:,}셀, 마이크로 청크 52×52. {len(regions)}개 장소, 이름 있는 연결 {len(links)}개, 완전 SOLID 6×6 구간 {checks['solid_6x6_windows']}개.
계수나무 허브의 6개 출입구가 사용되며, 이후 연결이 분기되어 도착 장소는 {checks['hub_distinct_neighbors']}개입니다.
일반 경로의 그래프 및 셀 연결을 확인했지만 실제 플랫폼 플레이의 전 구간 무아이템 완주는 입증하지 않았습니다.
절구 작업장 576셀은 지형이 아닌 예약입니다. Type0 감옥과 타임 캡슐은 일반 경로에서 밀폐됩니다.
핵심 진행 구역은 공간 역할 예시입니다. Unity 씬이나 기존 MCP 정본 파일을 변경하지 않았습니다.
희귀 장소는 시각 검토를 위해 고정 배치했습니다. 스폰 확률 실험이 아닙니다.

## 재생성
Python 3 + numpy, scipy, Pillow, reportlab, PyMuPDF가 필요합니다.
1. `python source/build_layout.py`
2. `python source/render_example.py`
원본 기하 템플릿은 `source/templates.json`에 포함되어 있습니다. 이전 216×144 결과를 데이터로 가져오거나 확대하지 않습니다.
도서관 책장, NPC, 동물, 열차 등은 설계 슬롯을 시각화한 도형이며 게임 아트가 아닙니다.
'''
(ROOT/'README.md').write_text(readme,encoding='utf8')

# Generated package keeps exact data and reproducible source. User-facing PNG/PDF
# are separate siblings; include them in the zip for a single complete handoff.
zip_path=OUT/'SPACE_EXAMPLE_624x416.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,6) as z:
    for p in sorted(ROOT.rglob('*')):
        keep=(p.is_relative_to(ROOT/'source') or p.is_relative_to(ROOT/'data') or p.name in ('README.md','tile_map.png','tile_map_numbered.png','route_map.png'))
        if p.is_file() and keep and '__pycache__' not in str(p):z.write(p,'SPACE_EXAMPLE/'+str(p.relative_to(ROOT)))
    for p in [pdfpath,overview_path,detail_path]:z.write(p,p.name)
print(json.dumps({'pdf':str(pdfpath),'pages':page_no,'overview':str(overview_path),'detail':str(detail_path),'zip':str(zip_path)},ensure_ascii=False,indent=2))
