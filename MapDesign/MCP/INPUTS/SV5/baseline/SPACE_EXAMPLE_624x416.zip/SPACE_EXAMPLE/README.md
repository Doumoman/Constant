# 마펠렁키 624×416 전체 타일 예시

사용자 피드백에 따라 작은 시범 구역을 늘려 그린 것이 아니라 **624×416 좌표 공간**에 101개 장소와 일반 구조를 재배치한 정적 설계 예시입니다.

## 보는 방법
- `SPACE_EXAMPLE_624x416.pdf`: 전체도, 구간 색인, 중앙 확대, A1–D4의 16개 확대도, 통로 확인도, 장소 색인, 검증 범위.
- `SPACE_EXAMPLE_624x416.png`: 전체 지도. `SPACE_EXAMPLE_DETAIL.png`: 동일 데이터의 중앙 구역 확대.
- `data/world_cells.csv`: x,y,cell,region. 원점은 왼쪽 아래. A=air / S=solid / O=one-way / R=reserved.
- `data/regions.json`: 장소 ID·크기·출입구·설계 속성. `connections.json`: 연결 의도 중심선.
- `data/ordinary_rooms.json`: 작은 방을 파낸 기록. 합쳐진 공간이 있으므로 항목 수를 최종 방 수로 해석하지 않습니다.
- `data/validation.json`: 전체 셀 검사. 점프 성공·무아이템 완주·상태 머신 검증은 포함하지 않습니다.

## 범위
전체 624×416 = 259,584셀, 마이크로 청크 52×52. 101개 장소, 이름 있는 연결 166개, 완전 SOLID 6×6 구간 0개.
계수나무 허브의 6개 출입구가 사용되며, 이후 연결이 분기되어 도착 장소는 7개입니다.
일반 경로의 그래프 및 셀 연결을 확인했지만 실제 플랫폼 플레이의 전 구간 무아이템 완주는 입증하지 않았습니다.
절구 작업장 576셀은 지형이 아닌 예약입니다. Type0 감옥과 타임 캡슐은 일반 경로에서 밀폐됩니다.
핵심 진행 구역은 공간 역할 예시입니다. Unity 씬이나 기존 MCP 정본 파일을 변경하지 않았습니다.
희귀 장소는 시각 검토를 위해 고정 배치했습니다. 스폰 확률 실험이 아닙니다.

## 재생성
Python 3 + numpy, scipy, Pillow, reportlab, PyMuPDF가 필요합니다.
1. `python source/build_layout.py`
2. `python source/render_example.py`
원본 기하 템플릿은 `source/templates.json`에 포함되어 있습니다. 이전 216×144 결과를 데이터로 가져오거나 확대하지 않습니다.
도서관 책장, NPC, 동물, 열차 등은 설계 슬롯을 시각화한 도형이며 게임 아트가 아닙니다.
