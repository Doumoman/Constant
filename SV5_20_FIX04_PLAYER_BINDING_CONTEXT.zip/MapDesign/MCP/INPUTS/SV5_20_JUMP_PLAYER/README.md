# SV5_20_JUMP_PLAYER package

This package stages the registered SV5_20 Task after accepted SV5_19.

The Task verifies the two 24×32 jump recipes with the existing live Player,
real Rigidbody2D/colliders, forward-only main traversal, and representative
miss recovery. It does not retune Player movement or inspect the whole world.

Run `STAGE.py --check`, `--stage`, and `--verify-staged`, then use the native
repository Apply flow. Do not make ad-hoc CHECK/FILES/VERIFY copies.

